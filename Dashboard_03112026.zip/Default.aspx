﻿<%@ Page Title="Home Page" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="FCTG_Dashboard._Default" %>

<%@ Register Src="common/filters.ascx" TagName="filters" TagPrefix="uc1" %>

<asp:Content ID="BodyContent" ContentPlaceHolderID="MainContent" runat="server">
    <asp:HiddenField ID="dashboardData" runat="server" ClientIDMode="Static" />

    <asp:HiddenField ID="agentProductivityData" runat="server" ClientIDMode="Static" />
    <uc1:filters ID="ucl_filters" runat="server" />


    <div class="kpis">
        <div class="kpi">
            <div class="kpi-icon volume-icon">
                <i class="fa-solid fa-chart-column"></i>
            </div>
            <div class="kpi-content">
                <div class="label">TOTAL PROCESSED VOLUME</div>
                <div class="value" id="kVolume">-</div>
                <div class="sub">All handled interactions</div>
                <div class="note" id="vNote">Across selected period</div>
            </div>
        </div>

        <div class="kpi">
            <div class="kpi-icon aht-icon">
                <i class="fa-solid fa-clock"></i>
            </div>
            <div class="kpi-content">
                <div class="label">AVERAGE HANDLING TIME</div>
                <div class="value" id="kAht">-</div>
                <div class="sub">Average seconds per interaction</div>
                <div class="note">Lower is generally better</div>
            </div>
        </div>

        <div class="kpi">
            <div class="kpi-icon sla-icon">
                <i class="fa-solid fa-circle-check"></i>
            </div>
            <div class="kpi-content">
                <div class="label">SLA ACHIEVED</div>
<%--                <div class="value" id="kSla">-</div>--%>
                <div class="value">TBD</div>
                <div class="sub">Volume-weighted SLA rate</div>
                <div class="note" id="slaNote">&nbsp;</div>
            </div>
        </div>

        <%--<div class="kpi">
            <div class="kpi-icon prod-icon">
                <i class="fa-solid fa-users"></i>
            </div>
            <div class="kpi-content">
                <div class="label">AVG. AGENT PRODUCTIVITY</div>
                <div class="value" id="kProd">-</div>
                <div class="sub">Illustrative productivity metric</div>
                <div class="note">Interactions per agent/day</div>
            </div>
        </div>--%>
    </div>

    <h2 class="section-title">Trend Analysis</h2>
    <div class="charts">
        <div class="panel">
            <button type="button"
                class="panel-expand-btn"
                onclick="expandPanel(this)"
                title="Expand panel">
                ⛶
            </button>
            <h3>Volume Trend</h3>
            <%--<p>Handled interactions across the selected time view</p>--%>
            <div class="chart-wrap">
                <div id="volumeChart" class="highchart-container"></div>
            </div>
        </div>
        <!-- Paused Count Chart -->
        <div class="panel">
            <button type="button"
                class="panel-expand-btn"
                onclick="expandPanel(this)"
                title="Expand panel">
                ⛶
            </button>
            <h3>Paused / Escalated Count</h3>
            <div class="chart-wrap">
                <div id="pausedEscalatedChart" class="highchart-container"></div>
            </div>
        </div>
        <!-- Escalated Count Chart -->
        <%--<div class="panel">
            <button type="button"
                class="panel-expand-btn"
                onclick="expandPanel(this)"
                title="Expand panel">
                ⛶
            </button>
            <h3>Escalated Count Trend</h3>
            <div class="chart-wrap">
                <div id="escalatedChart" class="highchart-container"></div>
            </div>
        </div>--%>

        <div class="panel">
            <button type="button"
                class="panel-expand-btn"
                onclick="expandPanel(this)"
                title="Expand panel">
                ⛶
            </button>
            <h3>Volume by Source Queue</h3>
            <%--<p>Distribution of handled interactions</p>--%>
            <div class="chart-wrap">
                <div id="queueChart" class="highchart-container"></div>
            </div>
        </div>
        <div class="panel">
            <button type="button"
                class="panel-expand-btn"
                onclick="expandPanel(this)"
                title="Expand panel">
                ⛶
            </button>
            <h3>Function-wise Volume</h3>
            <%--<p>Comparison of operational functions</p>--%>
            <div class="chart-wrap">
                <div id="functionChart" class="highchart-container"></div>
            </div>
        </div>
        <%--<div class="panel">
            <button type="button"
                class="panel-expand-btn"
                onclick="expandPanel(this)"
                title="Expand panel">
                ⛶
            </button>
            <h3>SLA Achievement Trend</h3>
            <%--<p>Actual SLA versus 90% target</p>
            <div class="chart-wrap">
                <div id="slaChart" class="highchart-container"></div>
            </div>
        </div>--%>
        <div class="panel">
            <button type="button"
                class="panel-expand-btn"
                onclick="expandPanel(this)"
                title="Expand panel">
                ⛶
            </button>
            <h3>AHT Trend</h3>
            <%-- <p>Average handling time in seconds</p>--%>
            <div class="chart-wrap">
                <div id="ahtChart" class="highchart-container"></div>
            </div>
        </div>
        <%--<div class="panel">
            <button type="button"
                class="panel-expand-btn"
                onclick="expandPanel(this)"
                title="Expand panel">
                ⛶
            </button>
            <h3>Agent Performance (AHT in min)</h3>
            <%--<p>Interactions handled by sample agents</p>
            <div class="chart-wrap">
                <div id="agentChart" class="highchart-container"></div>
            </div>
        </div>--%>

    </div>


    <h2 class="section-title">Function / Source Queue Performance Details
    </h2>

    <div class="panel table-wrap">
        <table id="performanceTable" class="display nowrap"
            style="width: 100%">
            <thead>
                <tr>
                    <th>Activity Date</th>
                    <th>Country Name</th>
                    <th>Function</th>
                    <th>Extraction Office</th>
                    <th>Queue Number</th>
                    <th>Queue Category</th>
                    <th>Inflow</th>
                    <th>In Process</th>
                    <th>Completed Count</th>
                    <th>Productivity (Seconds)</th>
                    <th>Average Handling Time</th>
                    <th>SLA Met</th>
                    <th>SLA Not Met</th>
                </tr>
            </thead>
            <tbody id="dataTable">
            </tbody>
        </table>
    </div>

</asp:Content>
