﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="filters.ascx.cs" Inherits="FCTG_Dashboard.common.filters" %>

<div class="filters">
    <div class="field">
        <label>TIME VIEW</label>
        <select id="period"
            onchange="updateTimeViewFilters(); updateDashboard()">
            <option value="yearly">Yearly</option>
            <option value="quarterly">Quarterly</option>
            <option value="monthly" selected>Monthly</option>
            <option value="weekly">Weekly</option>
            <option value="daily">Daily</option>
        </select>
    </div>

    <div class="field">
        <label>YEAR</label>
        <select id="year" onchange="updateDashboard()">
            <option value="all">All Years</option>
        </select>
    </div>

    <div class="field">
        <label>QUARTER</label>
        <select id="quarter" onchange="updateMonthDropdown(); updateDashboard()">
            <option value="all">All quarters</option>
            <option value="1">Q1</option>
            <option value="2">Q2</option>
            <option value="3">Q3</option>
            <option value="4">Q4</option>
        </select>
    </div>

    <div class="field">
        <label>MONTH</label>
        <select id="month" class="multi-select-source"
            onchange="updateDashboard()">
            <option value="all">All months</option>
            <option value="0">January</option>
            <option value="1">February</option>
            <option value="2">March</option>
            <option value="3">April</option>
            <option value="4">May</option>
            <option value="5">June</option>
            <option value="6">July</option>
            <option value="7">August</option>
            <option value="8">September</option>
            <option value="9">October</option>
            <option value="10">November</option>
            <option value="11">December</option>
        </select>
    </div>
    <div class="field" id="weekFilterField" style="display: none;">
        <label>WEEK</label>
        <select id="week" onchange="updateDashboard()">
            <option value="all">All weeks</option>
        </select>
    </div>
    <div class="field">
        <label>FUNCTION</label>
        <select id="func" runat="server"
            clientidmode="Static"
            class="multi-select-source"
            onchange="updateDashboard()">
            <option value="all" selected>All Functions</option>
        </select>
    </div>

    <div class="field">
        <label>SOURCE QUEUE</label>
        <select id="queue" onchange="updateDashboard()">
            <option value="all">All queues</option>
            <option>Voice</option>
            <option>Email</option>
            <option>Chat</option>
            <option>Cases</option>
        </select>
    </div>

    <div class="field">
        <label>LOCATION</label>
        <select id="office" class="multi-select-source"
            onchange="updateDashboard()">
            <option value="all">All Locations</option>
        </select>
    </div>

    <div class="field">
        <label>&nbsp;</label>
        <button type="button" class="primary"
            onclick="resetFilters()">
            Reset</button>
    </div>
</div>
