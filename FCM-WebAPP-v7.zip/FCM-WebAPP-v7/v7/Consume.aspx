﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Consume.aspx.cs" Inherits="QBay_WebApplication.Consume" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
        </div>
    </form>
    <script type="text/javascript" src="scripts/Consume.js">
    </script>
</body>
</html>
