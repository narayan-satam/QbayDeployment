window.location.replace("https://fcmuscasyd.qbay.wns.com/ADFS/Home/LoginUser");
