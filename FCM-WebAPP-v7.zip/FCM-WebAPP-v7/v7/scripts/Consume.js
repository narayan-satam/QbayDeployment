﻿function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    //return decodeURIComponent(results[2].replace(/\+/g, " "));
    return decodeURIComponent(results[2]);
}

localStorage.setItem("authparam", getParameterByName("param"));
var RedirecctURL = 'QBay\\index.html'
location.href = RedirecctURL;