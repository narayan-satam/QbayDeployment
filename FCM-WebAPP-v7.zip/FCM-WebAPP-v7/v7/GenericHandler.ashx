﻿<%@ WebHandler Language="C#" CodeBehind="GenericHandler.ashx.cs" Class="QBay_WebApplication.GenericHandler" %>
