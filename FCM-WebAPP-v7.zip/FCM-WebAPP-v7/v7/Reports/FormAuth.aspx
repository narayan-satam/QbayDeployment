﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="FormAuth.aspx.cs" Inherits="BasicFormAuthWebApp.FormAuth" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">


<head runat="server">
    <title></title>

    <style type="text/css">
        .hide {
            display: none;
        }

        .show {
            display: block;
           color:red;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div id="panel-1009-innerCt" data-ref="innerCt" style="" role="presentation" class="x-autocontainer-innerCt">
            <img class="x-img x-img-default" id="imgLogo" src="Qbay.png" alt="" style="margin-top: -10px; margin-left: 8px; height: 85px; width: 200px;" />
        </div>
        <div style="margin: auto; width: 50%; padding: 10px;">
            <div style="text-align: center">
                <h2>Active Job Queue Report</h2>
            </div>
            <div style="text-align: center">
                <lable>USERNAME</lable>:&nbsp;&nbsp;&nbsp;<asp:TextBox ID="m_textboxUserName" runat="server" /><br><br />
                <lable>PASSWORD</lable>:&nbsp;&nbsp;&nbsp;<asp:TextBox ID="m_textboxPassword" TextMode="password" runat="server" /><br />
                           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br />
                &nbsp;
          <%--  Remember password and weaken security?:
       <asp:CheckBox ID="m_bPersistCookie" runat="server" />
            <br />--%>
                <asp:Button Text="Download Report" OnClick="OnLogin"
                    runat="server" /><br />

             <%--   <div id="MyDiv" class="hide" runat="server">
                   Invalid Login!
                </div>--%>

                 <asp:Panel ID="MyDiv" CssClass="hide" runat="server">Invalid Login!</asp:Panel>
                <%-- <label id="lblMessage"></label>--%>
                <%--<asp:UpdatePanel>
                <asp:Label ID="lblMessage" runat="server" ForeColor="Red" Visible="false" EnableViewState="false"></asp:Label>
                    </asp:UpdatePanel>--%>
            </div>
            <br />
        </div>
    </form>
</body>
</html>
