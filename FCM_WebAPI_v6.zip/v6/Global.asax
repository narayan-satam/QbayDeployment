﻿<%@ Application Codebehind="Global.asax.cs" Inherits="QBay_WebAPI.WebApiApplication" Language="C#" %>
