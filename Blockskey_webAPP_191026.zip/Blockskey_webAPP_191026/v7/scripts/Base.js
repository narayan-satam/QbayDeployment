window.location.replace("https://blockskyeussyd.qbay.wns.com/ADFS/Home/LoginUser");
