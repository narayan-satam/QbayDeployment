
setTimeout(function () {
            
            var home = "https://wns.app.instasafe.io/";
            
            window.location.href=home;
}, 3000);
