var head = false;
var cols = 0;
function printStore(store, headers, th) {
    var a = store.data.items;
    var h = new Array();
    var hText = "";
    var d = new Array();
    log(store);
    log(a);
    for (var i = 0; i < a.length; i++) {
        for (var propName in a[i].data) {
            if (!(a[i].data[propName] instanceof Function)) {
                hText = findKey(propName, headers);
                if (hText!="") {
                    d.push(a[i].data[propName]);
                    if (i < 1) {
                        //h.push(propName);
                        h.push(hText);
                        cols++;
                    }
                }
            }
        }
    };

    var col = 0;
    var rw = new Array();
    var rs = new Array();
    for (var i = 0; i < d.length; i++) {
        if (col < cols) {
            rw.push(d[i]);
            col++;
            if (col == cols) {
                col = 0;
                rs.push(rw);
                rw = new Array();
            }
        }
    };
    var ret = "";
    if (th)
        ret = "<html><head><title>Export</title></head><body>";
    ret += t(h, rs, th);
    if (th)
        ret += "</body></html>";
    head = false;
    cols = 0;
    return ret;
}

function t(h, d, th) {
    if (th)
        return "<table id=\"data-table\" style=\"display:none\">" + tc(h, d, th) + "</table>";
    else
        return "<table id=\"data-table\">" + tc(h, d, th) + "</table>";
}

function tc(h, d, ih) {
    var ret = "";
    if (!head) {
        ret += "<tr>";
        for (var i = 0; i < h.length; i++) {
            if (ih)
                ret += th(h[i]);
            else
                ret += td(h[i]);
        };
        ret += "</tr>";
        head = true;
    }
    for (var i = 0; i < d.length; i++) {
        ret += "<tr>" + tdd(d[i]) + "</tr>";
    };
    return ret;
}

function tdd(d) {
    var ret = "";
    for (var i = 0; i < d.length; i++) {
        ret += td(d[i]);
    };
    return ret;
}

function td(d) {
    return "<td>" + d + "</td>";
}

function th(h) {
    return "<th>" + h + "</th>";
}

//==========================================================================================================

function exportToFile(tbldata, type, fn, dl) {
    var win = window.open("", "_blank", "toolbar=no,scrollbars=no,resizable=no,top=1,left=1,width=1,height=1");
    win.document.write(tbldata);
    var elt = win.document.getElementById('data-table');
    var wb = XLSX.utils.table_to_book(elt, { sheet: fn });
    win.close();
    return dl ?
        XLSX.write(wb, { bookType: type, bookSST: true, type: 'base64' }) :
        XLSX.writeFile(wb, fn || ('export.' + (type || 'xlsx')));
}

function generateReport(gridView, exportConfig) {
    var store = gridView.getStore();
    var headers = getHeaders(gridView);
    var table_html = printStore(store, headers, 1);
    var fType = exportConfig.fileType;
    var fName = exportConfig.fileName;
    exportToFile(table_html, fType, fName + "." + fType);
}

function getHeaders(gridView) {
    var headers = new Array();
    var hObj = {};
    var gridHeaders = gridView.headerCt.gridDataColumns;
    log(gridHeaders);

    for (var i = 0; i < gridHeaders.length; i++) {
        hObj = {
            "header": gridHeaders[i].dataIndex,
            "text": gridHeaders[i].config.text,
            "sequence": i
        };
        headers.push(hObj);
    }
    log(headers);
    return (headers);
}

function findKey(searchKey, collection) {
    var flag = false;
    var headerText = "";
    for (var i = 0; i < collection.length; i++) {
        if (searchKey == collection[i].header) {
            flag = true;
            headerText = collection[i].text;
            break;
        }
    }
    return headerText;
}