﻿var baseUrl = "http://localhost:8090/FCMTest/";
var buildDir = "QBay";
var clientCode = 'FCM'; var TeamLeadRef = '9579B846-A0FD-4D35-A26A-2538FC6B6901'; var TeamManagerRef = '4C5DA30E-DE44-448D-BCEB-6DDE35F284D0';


var privkey = '';
var pubkey = '';
var gatewayUrl = baseUrl + "GenericHandler.ashx";
var homeUrl = getHomeUrl();
var idpLogoutUrl = baseUrl + buildDir + "/IdpLogout.html";
var sessionResetUrl = baseUrl + "Index.aspx/ResetSession";
var reportURL = baseUrl + "Report.aspx";

var lang = "EN";
var userName;
var userKey;
var activeView;
var dashboardTimer = null;
var registeredTimers = null;
var pullbackTimer = null;
var authmode = "1";
var noAuth = "ClientAuth";
var maxSLALimit = "5000";
var AJQPageSize = 1000;

var AppVersion = "2.2";
var ServerNode = "Local";

var manualJobUploadTemplatePath = baseUrl + buildDir + "/resources/templates/JobList.xls";
var manualJobCompleteUploadTemplatePath = baseUrl + buildDir + "/resources/templates/JobCompleteList.xls";
var manualJobAllocationUploadTemplatePath =baseUrl + buildDir + "/resources/templates/JobAllocationList.xls";

var translationModule = 'F2C58F4F-B72A-490F-8485-F4C9D3F2796B';
var defaultSettingModule = 'AB024CD9-D443-4594-B233-068BEC7DD0CE';
var authenticationModule = 'DE352BC0-05EA-445B-9FEE-5C67C23045F0';
var userMasterModule = 'D78D49D4-99EC-4E39-83F6-47C15C67AE73';
var inputDataModule = '64ED79AD-C72B-40F2-A2AF-281C8440EB9E';
var SQLAuthentication = "0A08D5CF-E75E-433E-858C-30E6224D24F4";
var LDAPAuthentication = "7E7C0F42-5172-4589-AAC2-6BC5491C99FF";
var createUserModule = '80B41A99-499D-4939-AC0E-2BF1536341D2';
var createFunctionModule = '5D95522D-7DAC-45FA-A2D9-9A67E99F5007';
var functionMasterModule = 'D422F997-B078-4672-A357-6BB00056240B';
var createQueueModule = '9B081BBB-807B-45F8-9083-87044897CE7C';
var deleteQueueModule = '3C5CA51B-BCAC-4AAB-9951-E5B1115C59AA';
var createPriorityRuleModule = 'E69E4FF1-F2BC-4FDC-A52E-F13E655D9A67';
var deletePriorityRuleModule = '4B598DBA-636C-4D9F-93C7-892B4B8A2E29';
var createSkillModule = "482a6396-a740-4a73-bdca-7d46bc5abece";
var jobAllocationModule = '4E1A4A36-86C7-443E-A3C8-BCE434A532C1';
var skillMasterModule = '032C4C4A-DCAE-4174-AF1A-B5B0BA4BA6BE';
var userManagerModule = '5d046d9a-921c-4dca-a859-a97b3d6609f2';
var skillAssignmentModule = 'da8e8fe6-b511-4725-94f2-e93528fd1a5b';
var getSkillTypeModule = '677A5A04-D0FB-433F-919E-B493B2C8C9B2';
var processingModule = '5762A546-E9C8-446A-92B0-6518C6CF28D0';
var pausedModule = '15568D24-61E2-47A3-80CA-4F8200D24E00';
var escalationModule = 'B0018337-23F1-47BE-969D-5E790B21B98D';
var startBreakModule = '9F985D6E-CF10-4EE9-A40D-BD5271EE66B5';
var stopBreakModule = 'FB4D45A6-32A0-4221-B4F8-18811B687280';
var pnrCompleteModule = '6B075C8D-7F3C-4C4B-8E76-0B46779A5DE9';
var breakMasterModule = '762536E8-B595-474D-9631-CBC32EA9A2DD';
var monitoringReportsModule = 'D33917FC-F5B2-42CA-A985-18D394156AC0';
var insertManualPNRModule = '785B1397-544D-4295-8938-8193FD523367';
var jobReassignmentModule = '094D5F14-68FE-4114-8E38-144F938A396D';
var auditReportsModule = "CAF8D1B9-C9BC-45DE-B340-CE0F28284CDE";
var manualJobListModule = '65ECF696-B3DB-4C4F-A5BA-450137E465CC';
var agentProductivityReportsModule = 'DADA0A49-1569-4E3E-9708-ED92EE861887';
var inflowReportsModule = '1BD0BEDC-29C7-49CD-BD33-94B1E0ED0F9E';
var functionProductivityReportsModule = '67E3F0B7-E311-48AB-ABAD-3182163D0CDE';
var deleteFunctionModule = '3BF823FC-28B8-4F0F-90AD-2F76FDB04C8A';
var intervalSessionRequestModule = '8C8E78B9-1309-42A8-9799-AC1190E4431B';
var stallModule = '95B33521-3D3D-407D-92D6-FA266EDD35B6';
var stallResumeModule = '28A52C2F-0218-4DCC-9EC6-A977F76C8082';
var emailInflowReportsModule = '06C3518C-505D-48FB-9361-45BA02E6FB8E';
var SLAdetailsModule = '86A8EC7F-2231-4215-B66B-A3414B2E6EC9';
var deleteSLAModule = '6901068D-3AE4-4E3D-956D-A4DC023D5985';
var activeJobEmailReportModule = '711CA255-8C82-44BE-9C6C-9C78FA4D2204';
var activeJobQueueReportModule = 'CC1C581C-437B-46E1-86BD-0A984A50C087';
var agentBreakReportModule = '9FCF6553-C3DD-472E-B8DB-CF445A91AB6E';
var agentStatusReportModule = '4DADD9F0-C883-4C0A-838E-2A885117B600';
var emailLoadReportModule = 'F8654F05-83E5-429E-AA94-C629FCB11495';
var escalatedEmailJobsReportModule = '75CCC9B2-D5A3-45C8-B8B1-B0E74217E082';
var escalatedJobsReportModule = '6B74971B-6DA2-4080-B370-E9083DAB7257';
var holdEmailJobsReportModule = 'E5FFB4BA-E18B-4741-BF7E-07A8CEB908C4';
var holdJobsReportModule = '88257558-A882-4441-BC8C-11C25D83CB64';
var PNRLoadReportMoule = '96610270-F6F1-4B6A-A804-320341F13866';
var realTimeMonitoringModule = '070D6617-49C1-43A5-ABE4-A2E3598B2D3D';
var agentProductivityDailyReportModule = '183E3304-6BE1-4C21-AFA6-8DDA85BAE96F';
var agentProductivityMonthlyReportModule = 'C05995BF-5B41-49B4-946E-94C9D9BAE617';
var functionProductivityDailyReportModule = 'B199E952-E893-4044-B4BA-3F9100E82690';
var functionProductivityMonthlyReportModule = 'B0CADE3B-4215-4ADA-8F3C-5028C2E87523';
var dailyPNRInflowReportModule = '4742422C-3C17-4B71-99FD-8A8F6B1B41DA';
var monthlyPNRInflowReportModule = '1B2A2A93-D0BB-44D3-935D-C692BC40058B';
var dailyEmailInflowReportModule = 'AECC4BB2-4F12-4C32-9D5A-22C3FB2BBDC5';
var monthlyEmailInflowReportModule = '85CC5499-D6E8-4FEE-A3CA-7945E9F4A505';
var PNRCaseReportModule = 'A128A1EC-2890-4876-AF13-6C2AC54CFAD8';
var emailCaseReportModule = '126E0F1B-CC50-4B98-8D15-FBD44F3B8A93';
var PNRAuditReportModule = 'E5BA865A-A89F-48A9-8849-769D125DB45E';
var emailAuditReportModule = '9122015A-196A-4752-9DDE-D084B4D410B8';
var applicationAuditReportModule = '54DF8585-6EBB-40B0-8B66-31768D7E470B';
var userAuditModule = '206C40AC-F7AE-412C-B511-ECE194BA8F21';
var monitoringReportsModuleAgentDB = '7FA65E91-C75B-48B4-BAF7-FA7FFDBBE5F2';
var functionMasterModuleManualJA = '77546AB4-C584-4638-A18A-4AA952BE8007';
var emailProcessingModule = '8C669F9E-F2E2-4F11-9473-DC6367C3448B';
var insertEmailProcessingModule = 'BE973C4E-800A-4054-B339-9C18D336AC56';
var PNRStatusModule = '304D5B9E-137A-47A9-B86E-1DACBBE44A65';
var activeJobETrackReportModule = 'EA34D0E7-8F4C-4BDF-8878-42DDE0B686EF';
var escalatedETrackJobsReportModule = 'FEDC71F2-5930-447A-8780-00E8143BABA4';
var holdEtrackJobsReportModule = 'F3150257-EF91-430A-BDF5-BC5C9E511902';
var etrackLoadReportModule = 'C375EF27-0C22-40C2-919F-C9629E857369';
var etrackCaseReportModule = 'C8291978-AA5F-48BA-8575-6F87DC72E500';
var etrackAuditReportModule = '1AD7F132-2F8D-4F13-86CD-7573B8F536AA';
var dailyETrackInflowReportModule = 'F2E34F37-4343-4120-88E6-B8C31975E442';
var monthlyETrackInflowReportModule = '95E4AD62-E565-4A63-83F2-E02AC39F778E';
var getSLATimeModule = '47EF26C1-5BCC-4FCA-A139-1762DBD378FA';
var dailySLAFunctionReportModule = '68115125-1976-41D8-BDFA-A1560134F27E';
var monthlySLAFunctionReportModule = '1D42CE9B-C740-49CB-AF3A-3A04A0BF9BE5';
var agentProductivityHourlyReportModule = 'C92DB3C4-D04D-4ECC-AD36-A34231083405';
var agentBreakReportHourlyModule = '2C20BB39-3DDF-4B5D-9E7B-4B4772A96FBF';
var agentMonthlyAHTBYDayModule = '27AF17B6-71C3-45E2-ACD4-425844CBBBEA';
var agentMonthlyAHTBYWeekModule = '46666F37-C079-48F4-B4C0-5A2C1F39B401';
var agentAnnualAHTBYMonthModule = 'E0303598-61CD-4547-82AE-C1137D1ABACB';
var agentAnnualAHTBYWeekModule = '4DC3CF27-3726-453E-B451-5FF010C913A1';
var skillRuleNameByPNRModule = 'D3158238-AF98-463A-8426-EC3D3AC19FFA';
var functionMonthlyAHTBYDayModule = '250F2DC2-0E2C-498B-8770-ECA83A6208BD';
var functionMonthlyAHTBYWeekModule = '83B574C1-6B8B-4B45-8BA5-6FF808B67346';
var functionAnnualAHTBYWeekModule = '5B48CFBD-EE25-4594-B006-231A9957A0DE';
var functionAnnualAHTBYMonthModule = 'AB201550-56E7-4EF9-99B9-E3BB4961FF7C';
var hourlyInflowReportByDayModule = '099F66CD-A050-4A1A-B225-ABE22B844AB1';
var annualInflowReportByWeekModule = '51EB36F7-444B-4AC8-BD99-DC5ABA98CF1C';
var monthlyInflowReportByWeekModule = 'A59DBB1E-D052-4495-9596-BAAE6893FFDA';
var summerisedAnnualSLAReportByMonthModule = '6AC48DAE-4470-4D7D-949B-22E10FF73CC9';
var summerisedAnnualSLAReportByWeekModule = '0B88C081-6D77-4B79-A1F2-9E57EFDA2B05';
var summerisedMonthlySLAReportByDayModule = '7CA98B43-1A92-4789-B2F6-B0EC2348B621';
var summerisedMonthlySLAReportByWeekModule = 'D7172F50-0C45-42BC-9FCF-C4583B75FFF9';
var annualSLAReportByMonthModule = 'DEB5B7DE-0477-4C92-89DA-7F20F132089D';
var annualSLAReportByWeekModule = 'BC6DDC0F-8565-4E4F-A393-BB95FBBC58F7';
var hourlySLAReportByDayModule = 'EE546A28-C010-4F85-9DE2-79D4E9C084A9';
var monthlySLAReportByDayModule = 'C6B171D0-A1C6-4D6A-B6C8-3F2ED52AC427';
var monthlySLAReportByWeekModule = '475F8E22-0732-413C-BA0D-FF89E01EE8EE';
var agentLevelReportModule = '237BAD3B-AF31-4EF7-9C86-289B62B7BD73';
var monthlyPNRInflowReportWithoutDupeModule = 'F930FFFF-4487-4FA6-BC2B-41501B8D64F4';
var dailyPNRInflowReportWithoutDupeModule = '3D5FB6B2-9AD4-454F-A3B8-1230B181252B';
var getAllLobsModule = '90BA2BE5-F812-4087-B88B-CFABA5020C53';
var getAllFunctionsByLOBModule = 'AD6A20A0-9B09-414B-8165-E26D4BD1747B';
var getDashboardModule = 'A8B44E5C-D10F-44B6-B0C9-F815EDBEC750';
var getDashboardLiveQueueModule = '9891C28D-17EE-4295-AD03-147A9C372521';


function getHomeUrl() {
    var mode;
    noAuth = "ClientAuth";
    if (location.href.indexOf("?mode=") > 0) {
        mode = location.href.substr(location.href.indexOf("?mode=") + 6, noAuth.length);
    } else {
        mode = "hjkG7SF578fj";  // Dummy Value
    }

    if (authmode == null || mode == noAuth)
        return baseUrl + buildDir + "/index.html?mode=" + noAuth;
    else
        return baseUrl + "index.aspx";
}

function clearStorage(type) {
    if (type == "S") {
        sessionStorage.clear();
    }
    else if (type == "L") {
        localStorage.clear();
    }
    else {
        sessionStorage.clear();
        localStorage.clear();
    }
}

function QbyEncrypt(obj) {
    return Ext.JSON.encode(obj);
}

function QbyDecrypt(str) {
    return Ext.JSON.decode(str);
}

function getClientCode() {
    return clientCode;
}

//function getUserKey() {
//    var userObj = QbyDecrypt(retrieveItem("LGINF", "S"));
//    return userObj.USER_KEY;
//}


function setLoadingText(text) {
    log(text);
    //    document.getElementById("loading").innerHTML = text;
}


function stopLoading() {
    //    document.getElementById("loading").innerHTML = "";
}

function getPageBodyHeight() {
    var height = Ext.getCmp('mainPort').getHeight() - Ext.getCmp('northRegion').getHeight() - Ext.getCmp('southRegion').getHeight() - Ext.getCmp('bodyContainer').getHeight() - 20;
    return height;
}



function applydefaultSettings() {
    var defaultObj = QbyDecrypt(retrieveItem("DEFS", "S"));
    var languageCode = retrieveItem("LANG", "S");
    lang = languageCode;
}

function getGatewayUrl() {
    return gatewayUrl;
}

function storeItem(key, val, type) {
    switch (type) {
        case "S":
            sessionStorage.setItem(key, val);
            break;
        default:
            localStorage.setItem(key, val);
    }

}

function log(text) {

    console.log(text);
}

function getTwoDigitsNum(num) {
    if (num >= 10)
        return num;
    else
        return "0" + num;
}

function getActiveUserName() {
    //log("Retrieving UINFO " + retrieveItem("LGINF", "S"));
    return (retrieveItem("LGINF", "S") && retrieveItem("LGINF", "S") != null) ? QbyDecrypt(retrieveItem("LGINF", "S")).FIRST_NAME : 'User';
}

function getActiveUserKey() {
    return (retrieveItem("LGINF", "S") && retrieveItem("LGINF", "S") != null) ? QbyDecrypt(retrieveItem("LGINF", "S")).USER_KEY : '';
}

function getClientLogo() {
    var logo = (retrieveItem("DEFS", "S") && retrieveItem("DEFS", "S") != null) ? QbyDecrypt(retrieveItem("DEFS", "S")).LOGO : 'QBay.png';
    logo = 'Resources/images/' + logo;
    return logo;
}

function getLogoStyle() {
    var cCode = getClientCode().toUpperCase();
    //log("getting style for " + cCode);
    var style = '';
    switch (cCode) {
        case "AC":
            style = {
                'margin-top': '8px',
                'margin-left': '8px'
            };
            break;
        case "WNS":
            style = {
                'margin-top': '-10px',
                'margin-left': '8px',
                'height': '85px',
                'width': '200px'
            };
            break;
        case "AIR123":
            style = {
                'margin-top': '8px',
                'margin-left': '8px'
            };
            break;
        case "FCTG":
            style = {
                'margin-top': '8px',
                'margin-left': '8px'
            };
            break;
        default:
            style = {
                'margin-top': '-10px',
                'margin-left': '8px',
                'height': '85px',
                'width': '200px'
            };
    }
    return style;
}

function getQBayLogo() {
    return 'Resources/images/Qbay.png';
}

function getClientName() {
    var clientName = (retrieveItem("DEFS", "S") && retrieveItem("DEFS", "S") != null) ? QbyDecrypt(retrieveItem("DEFS", "S")).CLIENT_NAME : 'WNS Global Services';
    return clientName;
}

function retrieveItem(key, type) {
    var val = "";
    switch (type) {
        case "S":
            val = sessionStorage.getItem(key);
            break;
        default:
            val = localStorage.getItem(key);
    }
    return val;
}

function removeItem(key, type) {
    switch (type) {
        case "S":
            sessionStorage.removeItem(key, val);
            break;
        default:
            localStorage.removeItem(key, val);
    }
}

function getTranslationModelData(transObj) {
    var i = 0;
    var modelObj = {};
    var str = "{";
    for (i = 0; i < transObj.length; i++) {
        str += "'" + transObj[i].TEXT_KEY + "':'" + transObj[i].TEXT_VALUE + "'";
        if (i < transObj.length - 1)
            str += ",";
        modelObj[transObj[i].TEXT_KEY] = transObj[i].TEXT_VALUE;

        if (transObj[i].TEXT_KEY.substring(0, 3).toLowerCase() == "mod") {
            setPageTitle(transObj[i].TEXT_VALUE);
        }
    }
    str += "}";

    // log(modelObj);
    //modelObj = Ext.JSON.decode(str);
    return modelObj;
}

function setPageTitle(text) {
    Ext.getCmp('pageTitle').setText(text);
}

function translateUILang(baseObj) {
    var translateText = [];
    var langData = baseObj.getViewModel().getData();
    activeView = baseObj;
    for (var prop in langData) {
        if (langData.hasOwnProperty(prop)) {
            translateText.push({
                "TEXT_KEY": prop
            })
        }
    }

    Ext.Ajax.request({
        url: gatewayUrl,
        method: "POST",
        jsonData: QbyEncrypt({
            Header: {
                CLIENT_CODE: getClientCode(),
                MODULE_ID: translationModule,
                ACTION: 'GetTranslatedLanguageDetails'
            },
            Body: {
                TRANSLATE_INFO: Ext.JSON.encode({
                    TRANSLATE_TO: lang,
                    TRANSLATE_TEXT: translateText
                })
            }
        }),
        scope: baseObj,

        success: function (response, opts) {
            var obj = QbyDecrypt(QbyDecrypt(response.responseText));
            if (obj.ResponseStatus == 'Success') {
                var modelData = getTranslationModelData(obj.SuccessParams.TRANSLATE_TEXT);
                log("Model Data");
                log(modelData);
                baseObj.getViewModel().setData(modelData);
                baseObj.langData = modelData;
                baseObj.getViewModel().notify();
            } else {
                log("Failed to Translate");
            }
        },

        failure: function (response, opts) {
            log("Failure", 'Server-side failure with status code ' + response.status);
        }
    });
}


function cleanupFields(container) {
    var obj;
    for (var i = 0; i < container.items.length; i++) {
        obj = container.items[i];
        if (obj.isContainer == true) {
            this.cleanupFields(obj.items);
        }
        else {
            if (obj.getXType() != 'button')
                obj.setValue("");
        }
    }
}

function getUTCNow() {
    //This function returns current UTC time in milliseconds
    var now = new Date();
    var time = now.getTime();
    var offset = now.getTimezoneOffset();
    var utcNow = parseInt(time) + (parseInt(offset) * 60000);
    //log("UTC Now=" + utcNow);
    return utcNow;
}


function getUTCTime(datetime) {

    //expected format : "Nov 01 2018 5:06:09 AM"

    var dt = new Date(datetime);
    var utc = new Date(dt.getTime() + dt.getTimezoneOffset() * 60000);
    return utc;
}

function truncate(x) {
    if (isNaN(x)) {
        return NaN;
    }
    if (x > 0) {
        return Math.floor(x);
    }
    return Math.ceil(x);
}

function handleFailure(failureResponse) {

}

function initSession() {
    log("Session Initiated");
    var ping = setInterval(function () {
        keepMeAlive();
    }, 300000);
}


function keepMeAlive() {
    log("keepalive");
    Ext.Ajax.request({
        url: gatewayUrl,
        method: "POST",
        jsonData: QbyEncrypt({
            Header: {
                CLIENT_CODE: getClientCode(),
                MODULE_ID: intervalSessionRequestModule,
                ACTION: 'IntervalSessionRequest'
            },
            Body: {
                SessionInfo: QbyEncrypt({
                    USER_KEY: getActiveUserKey(),
                    LAST_ACTIVITY_TIME: "[~]"
                })
            }
        }),
        success: function (response, opts) {

            var obj = QbyDecrypt(QbyDecrypt(response.responseText));

            if (obj.ResponseStatus == 'Failure' || obj.FailureParams.ErrorCode == "000") {
                //Ext.Msg.alert("Session Expired", "Session has been expired. You'll be redirected to login page now.");
                Ext.Msg.show({
                    title: 'Session Expired',
                    message: "Session has been expired. You'll be redirected to login page now.",
                    autoSize: true,
                    buttons: Ext.MessageBox.OK,
                    icon: Ext.Msg.ERROR,
                    modal: true,
                    scope: this,
                    fn: function (itemId) {
                        log("inside func. Item Id: " + itemId);

                        if (itemId == 'ok') {
                            doLogout();
                        }
                    }
                });
                //doLogout();
            }
        },

        failure: function (response, opts) {
            log("Failure", 'Server-side failure with status code ' + response.status);
            //loadMask1.destroy();
        }
    });

}

function setUserRole() {
    var userInfo = QbyDecrypt(retrieveItem("LGINF", "S"));
    var i, j;
    var finalRole = {};
    if (userInfo != null) {
        var userRoles = userInfo.ROLES;
        for (i = 0; i < userRoles.length; i++) {
            switch (userRoles[i].ROLE_NAME) {
                case "Agent":
                    userRoles[i].weight = 1;
                    break;
                case "Team Lead":
                    userRoles[i].weight = 2;
                    break;
                case "Team Manager":
                    userRoles[i].weight = 3;
                    break;
                case "Res Ops":
                default:
                    userRoles[i].weight = 100;
            }
        }
        finalRole = userRoles[0];
        for (i = 0; i < userRoles.length; i++) {
            if (userRoles[i].weight > finalRole.weight) {
                finalRole = userRoles[i];
            }
        }
        log("role" + finalRole);
        storeItem("ROLE", QbyEncrypt(finalRole), "S");
    }
}

function getSprites(value) {
    var sprites = [];
    var obj;
    obj = {
        listeners: {
            render: 'onLabelBind'
        },
        type: 'text',
        text: 'Inflow vs Outflow',
        textAlign: 'center',
        fontSize: 18,
        fontWeight: 'bold',
        width: 100,
        height: 30,
        x: screen.width / 2, // the sprite x position
        y: 30,  // the sprite y position
        fillStyle: 'White'
    };
    sprites.push(obj);
    obj = {
        type: 'text',
        text: value,
        //bind:{
        //    text: '{}'
        //    },
        textAlign: 'center',
        fontSize: 16,
        x: screen.width / 2,
        y: 50,
        fillStyle: 'White'
    };
    sprites.push(obj);
    return sprites;
}

function validateSession(response) {
    log("Validating Session");
    var obj = QbyDecrypt(QbyDecrypt(response.responseText));
    log(obj);
    if (obj.FailureParams.ErrorMessage == "SESSION TIMEOUT" || obj.FailureParams.ErrorCode == "000") {
        log("Log Out After SESSION Validation");
        //Ext.Msg.alert("Session Expired", "Session has been expired. You'll be redirected to login page now.");
        //doLogout();
        Ext.Msg.show({
            title: 'Session Expired',
            message: "Session has been expired. You'll be redirected to login page now.",
            autoSize: true,
            buttons: Ext.MessageBox.OK,
            icon: Ext.Msg.ERROR,
            modal: true,
            scope: this,
            fn: function (itemId, value, opt) {
                log("inside MSGShow func. Item Id: " + itemId);

                if (itemId == 'ok') {
                    doLogout();
                }
            }
        });

    } else if (obj.FailureParams.ErrorCode == "001") {
        log("Unauthorised module called");

        //Ext.Msg.alert('Not Authorised', "You seems to have performed a suspecious activity which you are not authorised for. You'll be redirected to login page now.", function () {
        //    doLogout();
        //});

        Ext.Msg.show({
            title: 'Not Authorised',
            message: "You seems to have performed a suspecious activity which you are not authorised for. You'll be redirected to login page now.",
            autoSize: true,
            buttons: Ext.MessageBox.OK,
            icon: Ext.Msg.ERROR,
            modal: true,
            scope: this,
            fn: function (itemId) {
                log("inside func. Item Id: " + itemId);

                if (itemId == 'ok') {
                    doLogout();
                }
            }
        });
        //doLogout();
    }
}

function alertPropmpt(itemId) {
    log(itemId);
    if (itemId == 'ok') {
        doLogout();
    }
}

function doLogout() {
    log("Logging out");
    Ext.Ajax.request({
        url: gatewayUrl,
        method: "POST",
        jsonData: QbyEncrypt({
            Header: {
                CLIENT_CODE: getClientCode(),
                ACTION: 'logout',
                USER_KEY: getActiveUserKey()
            }
        }),
        scope: this,

        success: function (response, opts) {
            clearStorage("B");  //Clear both local and session storage.
            //alert('session cleared');

            var logoutUrl = idpLogoutUrl + '?mode=' + noAuth;
            //window.location.replace(idpLogoutUrl);
            window.location.replace(logoutUrl);
        },

        failure: function (response, opts) {
            log("Failure", 'Server-side failure with status code ' + response.status);
        }
    });
}

function registerTimer(timerName, timerObj) {
    if (registeredTimers == null) {
        registeredTimers = new Ext.util.Collection();
    }
    if (registeredTimers.indexOfKey(timerName) < 0) {
        registeredTimers.add(timerObj);
    }
}


function encrypt(data) {
    var key = CryptoJS.enc.Utf8.parse('8080808080808080');
    var iv = CryptoJS.enc.Utf8.parse('8080808080808080');

    var encryptedData = CryptoJS.AES.encrypt(data, key,
    {
        keySize: 128 / 8,
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    });
    encryptedData = encryptedData.toString();
    //debugger;
    
    do {
        encryptedData = encryptedData.replace('+', '%2B');
    }
    while (encryptedData.indexOf('+') >= 0);
    do {
       encryptedData = encryptedData.replace('/', '%2F');
    }
    while (encryptedData.indexOf('/') >= 0) ;
      
    do {
       encryptedData = encryptedData.replace('=', '%3D');
    }
    while (encryptedData.indexOf('=') >= 0);

    return encryptedData;
}