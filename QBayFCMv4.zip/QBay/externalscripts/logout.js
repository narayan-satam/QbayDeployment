
setTimeout(function () {
            
            var home = "https://fctg.okta.com/app/fctg_qbay_2/exk1bg19dcq4877f52p8/sso/saml";
            
            window.location.href=home;
}, 3000);
